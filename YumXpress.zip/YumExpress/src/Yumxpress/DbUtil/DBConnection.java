/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Yumxpress.DbUtil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author pc
 */
public class DBConnection {
    private static Connection Conn;
    static{
        try{
            Conn=DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/xe", "yumxpress", "foodie");
            JOptionPane.showMessageDialog(null,"Connection Opened");
            
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Cannot open connection");
            ex.printStackTrace();
        }
    }
    public static Connection getConnection(){
        return Conn;
    }
    public static void closeConnection(){
        try{
           Conn.close();
        }
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Cannot  close connection");
            ex.printStackTrace();
        }
    }
}
