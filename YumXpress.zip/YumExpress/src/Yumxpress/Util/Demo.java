/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Yumxpress.Util;

import java.util.Base64;
import org.apache.commons.validator.EmailValidator;

/**
 *
 * @author pc
 */
public class Demo {
    public static void main(String[] args) {
        String pwd="admin";
        Base64.Encoder en=Base64.getEncoder();
        String Encrypted=en.encodeToString(pwd.getBytes());
        System.out.println("Original pwd:"+pwd);
        System.out.println("Encrypted pwd:"+Encrypted);
        Base64.Decoder dec=Base64.getDecoder();
        byte[] arr=dec.decode(Encrypted.getBytes());
        String decpwd=new String(arr);
        System.out.println("decrypted pwd:"+decpwd);
   org.apache.commons.validator.routines.EmailValidator validator=org.apache.commons.validator.routines.EmailValidator.getInstance();      
        String emailid1="scalive4u@gmail.com";
        System.out.println("email:"+emailid1+"valid:"+validator.isValid(emailid1));
         String emailid2="scalive4ugmail.com";
         System.out.println("email:"+emailid2+"valid:"+validator.isValid(emailid2));
    }
}
